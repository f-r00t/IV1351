--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 17.1 (Postgres.app)
-- Dumped by pg_dump version 17.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE harry;
--
-- Name: harry; Type: DATABASE; Schema: -; Owner: harry
--

CREATE DATABASE harry WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.UTF-8';


ALTER DATABASE harry OWNER TO harry;

\connect harry

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: contact_type; Type: TABLE DATA; Schema: public; Owner: harry
--

COPY public.contact_type (contact_type_id, contact_type) FROM stdin;
\.
COPY public.contact_type (contact_type_id, contact_type) FROM '$$PATH$$/3809.dat';

--
-- Data for Name: person_type; Type: TABLE DATA; Schema: public; Owner: harry
--

COPY public.person_type (person_type_id, person_type) FROM stdin;
\.
COPY public.person_type (person_type_id, person_type) FROM '$$PATH$$/3811.dat';

--
-- Data for Name: person; Type: TABLE DATA; Schema: public; Owner: harry
--

COPY public.person (person_id, personal_number, name, teaches_ensamble, person_type) FROM stdin;
\.
COPY public.person (person_id, personal_number, name, teaches_ensamble, person_type) FROM '$$PATH$$/3788.dat';

--
-- Data for Name: contact_details; Type: TABLE DATA; Schema: public; Owner: harry
--

COPY public.contact_details (value, person_id, contact_type_id) FROM stdin;
\.
COPY public.contact_details (value, person_id, contact_type_id) FROM '$$PATH$$/3794.dat';

--
-- Data for Name: genre; Type: TABLE DATA; Schema: public; Owner: harry
--

COPY public.genre (genre_id, genre) FROM stdin;
\.
COPY public.genre (genre_id, genre) FROM '$$PATH$$/3804.dat';

--
-- Data for Name: instrument_type; Type: TABLE DATA; Schema: public; Owner: harry
--

COPY public.instrument_type (instrument_id, type) FROM stdin;
\.
COPY public.instrument_type (instrument_id, type) FROM '$$PATH$$/3800.dat';

--
-- Data for Name: lesson_type; Type: TABLE DATA; Schema: public; Owner: harry
--

COPY public.lesson_type (id, lesson_type) FROM stdin;
\.
COPY public.lesson_type (id, lesson_type) FROM '$$PATH$$/3806.dat';

--
-- Data for Name: skill_level; Type: TABLE DATA; Schema: public; Owner: harry
--

COPY public.skill_level (skill_type_id, skill_type) FROM stdin;
\.
COPY public.skill_level (skill_type_id, skill_type) FROM '$$PATH$$/3802.dat';

--
-- Data for Name: lesson; Type: TABLE DATA; Schema: public; Owner: harry
--

COPY public.lesson (lesson_id, instrument_type, max_students, min_students, person_id, genre, lesson_type, skill_level) FROM stdin;
\.
COPY public.lesson (lesson_id, instrument_type, max_students, min_students, person_id, genre, lesson_type, skill_level) FROM '$$PATH$$/3798.dat';

--
-- Data for Name: enrollment; Type: TABLE DATA; Schema: public; Owner: harry
--

COPY public.enrollment (person_id, lesson_id) FROM stdin;
\.
COPY public.enrollment (person_id, lesson_id) FROM '$$PATH$$/3789.dat';

--
-- Data for Name: fee; Type: TABLE DATA; Schema: public; Owner: harry
--

COPY public.fee (start_date, fee, lesson_type, skill_level) FROM stdin;
\.
COPY public.fee (start_date, fee, lesson_type, skill_level) FROM '$$PATH$$/3796.dat';

--
-- Data for Name: instructor_instrument; Type: TABLE DATA; Schema: public; Owner: harry
--

COPY public.instructor_instrument (person_id, instrument_id) FROM stdin;
\.
COPY public.instructor_instrument (person_id, instrument_id) FROM '$$PATH$$/3807.dat';

--
-- Data for Name: instruments; Type: TABLE DATA; Schema: public; Owner: harry
--

COPY public.instruments (instrument_id, brand, fee, rented, instrument_type) FROM stdin;
\.
COPY public.instruments (instrument_id, brand, fee, rented, instrument_type) FROM '$$PATH$$/3792.dat';

--
-- Data for Name: rentals; Type: TABLE DATA; Schema: public; Owner: harry
--

COPY public.rentals (start_time, end_time, person_id, instrument_id) FROM stdin;
\.
COPY public.rentals (start_time, end_time, person_id, instrument_id) FROM '$$PATH$$/3793.dat';

--
-- Data for Name: schedule; Type: TABLE DATA; Schema: public; Owner: harry
--

COPY public.schedule (starttime, endtime, lesson_id) FROM stdin;
\.
COPY public.schedule (starttime, endtime, lesson_id) FROM '$$PATH$$/3790.dat';

--
-- Data for Name: sibling; Type: TABLE DATA; Schema: public; Owner: harry
--

COPY public.sibling (person_id, sibling) FROM stdin;
\.
COPY public.sibling (person_id, sibling) FROM '$$PATH$$/3795.dat';

--
-- Name: contact_type_contact_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: harry
--

SELECT pg_catalog.setval('public.contact_type_contact_type_id_seq', 7, true);


--
-- Name: genre_genre_id_seq; Type: SEQUENCE SET; Schema: public; Owner: harry
--

SELECT pg_catalog.setval('public.genre_genre_id_seq', 10, true);


--
-- Name: instrument_type_instrument_id_seq; Type: SEQUENCE SET; Schema: public; Owner: harry
--

SELECT pg_catalog.setval('public.instrument_type_instrument_id_seq', 10, true);


--
-- Name: instruments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: harry
--

SELECT pg_catalog.setval('public.instruments_id_seq', 20, true);


--
-- Name: lesson_lesson_id_seq; Type: SEQUENCE SET; Schema: public; Owner: harry
--

SELECT pg_catalog.setval('public.lesson_lesson_id_seq', 1, false);


--
-- Name: lesson_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: harry
--

SELECT pg_catalog.setval('public.lesson_type_id_seq', 3, true);


--
-- Name: person_id_seq; Type: SEQUENCE SET; Schema: public; Owner: harry
--

SELECT pg_catalog.setval('public.person_id_seq', 46, true);


--
-- Name: person_type_person_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: harry
--

SELECT pg_catalog.setval('public.person_type_person_type_id_seq', 3, true);


--
-- Name: skill_level_skill_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: harry
--

SELECT pg_catalog.setval('public.skill_level_skill_type_id_seq', 3, true);


--
-- PostgreSQL database dump complete
--

